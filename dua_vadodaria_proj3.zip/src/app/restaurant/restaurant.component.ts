import { Component, OnInit } from "@angular/core";
import { LoginCheckService } from "../services/login-check.service";
import { Restaurant } from "../models/restaurant.model";
import { RestaurantsService } from "../services/restaurants.service";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: "app-restaurant",
  templateUrl: "./restaurant.component.html",
  styleUrls: ["./restaurant.component.scss"]
})
export class RestaurantComponent implements OnInit {
  restaurant: Restaurant;
  menu: any = {};
  classifications: any = {};
  Objectkeys = Object.keys;
  reviews: any[];
  userReview: string = "";

  constructor(
    private loginCheck: LoginCheckService,
    private restroService: RestaurantsService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.loginCheck.do();

    this.restroService.getRestaurant(this.route.snapshot.paramMap.get("uuid"))
    .subscribe(resp => this.restaurant = resp);

    this.restroService.getMenu(this.route.snapshot.paramMap.get("uuid"))
    .subscribe(resp => {
      if (!resp) return;
      this.menu = resp.menu || {};
      this.classifications = resp.classifications || {};
    });

    this.restroService.getReviews(this.route.snapshot.paramMap.get("uuid"))
      .subscribe(resp => {this.reviews = resp});
  }

  public submitReview() {
    this.restroService.postReview(this.route.snapshot.paramMap.get("uuid"), 
    {
      review: this.userReview,
      reviewer: localStorage.getItem("login_name"),
      reviewerName: localStorage.getItem("login_fullName")
    });
  }
}
