export interface Restaurant {
    title: String;
    uuid: String;
    feedback: any;
}