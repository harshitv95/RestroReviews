module.exports = {
    connectionString: "mongodb://localhost:27017/retro_reviews"
}